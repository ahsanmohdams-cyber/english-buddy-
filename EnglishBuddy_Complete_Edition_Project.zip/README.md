# English Buddy – Complete Edition

Malayalam-first English reading practice app for Android.

## Included
- Android WebView app shell and offline lesson content.
- 10 staged learning levels, progress saved locally on the device.
- Positive, child-friendly Malayalam teaching language.
- English word read-aloud and Malayalam instruction read-aloud using device text-to-speech voices when installed.
- Question order randomization, per-level seen-question tracking, retry/review flow, stars and progress.
- Basic in-app error recovery (safe reload prompt) and diagnostic logging.
- GitHub Actions workflow to build a debug APK.

## Important honest limitations
- This is an offline learning app, not a cloud generative-AI tutor. No API key or internet access is needed.
- It does not yet listen to or grade a child's spoken pronunciation. Device text-to-speech reads examples aloud; it is not speech recognition.
- The course has curated question pools. It varies their order and revisits skills; it cannot promise never to repeat a question forever. Repeated practice in new contexts is educationally useful.
- Completing all app levels is not a professional certification or proof of fluent reading. A parent/teacher should listen to the child read unfamiliar material.
- The app cannot guarantee that every possible software bug will self-fix. It catches common page errors and offers safe recovery.

## Build APK with GitHub Actions
1. Upload all files and folders in this project to the root of your GitHub repository.
2. Open the repository's **Actions** tab.
3. Enable workflows if GitHub asks.
4. Choose **Build English Buddy APK** → **Run workflow**.
5. When it finishes, open the run and download **English-Buddy-Complete-APK** under Artifacts.
6. The APK inside the artifact ZIP is `app-debug.apk`.

The APK is a debug build for testing. A public Play Store release needs a separately signed release build and appropriate testing.
